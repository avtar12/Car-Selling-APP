package com.verma.asdf.carsell;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AstornMartin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_astorn_martin);
        Button buynow8 = (Button) findViewById(R.id.buynow8);
        buynow8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent buy8 = new Intent(AstornMartin.this, AddressBuy.class);
                startActivity(buy8);
            }
        });
    }
}
