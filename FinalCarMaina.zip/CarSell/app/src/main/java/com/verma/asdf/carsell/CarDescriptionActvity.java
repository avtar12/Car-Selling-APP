package com.verma.asdf.carsell;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.verma.asdf.carsell.beans.CarItem;

public class CarDescriptionActvity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_description1);
        Intent intent=getIntent();
        
        if(intent!=null)
        {
            CarItem carItem=(CarItem)intent.getSerializableExtra("caritem");
            System.out.println("carItem.getTitle() = " + carItem.getTitle());
            
        }
        else{
            Toast.makeText(this, "No detail found", Toast.LENGTH_SHORT).show();
            finish();
        }
    }
}
