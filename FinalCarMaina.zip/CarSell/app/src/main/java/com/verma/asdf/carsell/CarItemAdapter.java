package com.verma.asdf.carsell;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.verma.asdf.carsell.beans.CarItem;

import java.util.ArrayList;

public class CarItemAdapter extends BaseAdapter {
    Context context;
    ArrayList<CarItem> arrayList;
    public CarItemAdapter(Context context, ArrayList<CarItem> arrayList)
    {
        this.context=context;
        this.arrayList=arrayList;

    }
    @Override
    public int getCount() {
        return arrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return arrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
       View view= LayoutInflater.from(context).inflate(R.layout.caritem,parent,false);
      String s=arrayList.get(position).getTitle();
      String modle=arrayList.get(position).getModel();
        String engine1=arrayList.get(position).getEngine();
        String ccpower2=arrayList.get(position).getCcpower();
        String price3=arrayList.get(position).getPrice();
        //String ratingss=arrayList.get(position).getRating();
        LinearLayout linearLayout=(LinearLayout)view.findViewById(R.id.layer0) ;
        TextView title=(TextView)view.findViewById(R.id.title);
        TextView model=(TextView)view.findViewById(R.id.model);
        TextView engine = (TextView)view.findViewById(R.id.engine);
        TextView ccpower=(TextView)view.findViewById(R.id.ccpower);
        TextView price = (TextView)view.findViewById(R.id.price);
        //TextView rating =(TextView)view.findViewById(R.id.rating);
        ImageView imageView=(ImageView) view.findViewById(R.id.imageView);
        Integer imaguurl=arrayList.get(position).getImageurl();
        title.setText(s);
        model.setText("Model: "+modle);
        ccpower.setText("Displacement: "+ccpower2);
        price.setText("Price:  ₹"+price3);
        engine.setText("Engine: "+engine1);
        //rating.setText("Rating "+ratingss);
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CarItem carItem=arrayList.get(position);
                if (position==0){
                    Intent intent=new Intent(context,BuggatiVeyron.class);

                    context.startActivity(intent);
                }
                if (position==1){
                    Intent intent=new Intent(context,Ferrari488.class);

                    context.startActivity(intent);
                }
                if (position==2){
                    Intent intent=new Intent(context,LamborghiniHuracan.class);

                    context.startActivity(intent);
                }
                if (position==3){
                    Intent intent=new Intent(context,Ferrari812.class);

                    context.startActivity(intent);
                }
                if (position==4){
                    Intent intent=new Intent(context,Porsche911.class);

                    context.startActivity(intent);
                }
                if (position==5){
                    Intent intent=new Intent(context,AudiR8.class);

                    context.startActivity(intent);
                }
                if (position==6){
                    Intent intent=new Intent(context,FordGt.class);

                    context.startActivity(intent);
                }
                if (position==7){
                    Intent intent=new Intent(context,AstornMartin.class);

                    context.startActivity(intent);
                }
                if (position==8){
                    Intent intent=new Intent(context,LamborghiniAvantador.class);

                    context.startActivity(intent);
                }
                if (position==9){
                    Intent intent=new Intent(context,HondaNsx.class);

                    context.startActivity(intent);
                }
                if (position==10){
                    Intent intent=new Intent(context,McLaren.class);

                    context.startActivity(intent);
                }
               

            }
        });

        if(imaguurl>0) {
            imageView.setImageResource(imaguurl);
        }
        return view;
    }
}
