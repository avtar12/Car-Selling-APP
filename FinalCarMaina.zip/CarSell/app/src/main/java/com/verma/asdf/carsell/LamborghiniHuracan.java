package com.verma.asdf.carsell;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class LamborghiniHuracan extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lamborghini_huracan);
        Button buynow3 = (Button) findViewById(R.id.buynow3);
        buynow3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent buy3 = new Intent(LamborghiniHuracan.this, AddressBuy.class);
                startActivity(buy3);
            }
        });
    }
}
