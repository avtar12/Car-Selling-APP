package com.verma.asdf.carsell;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ListView;

import com.verma.asdf.carsell.beans.CarItem;

import java.util.ArrayList;

public class CarViewActivity2  extends AppCompatActivity implements View.OnClickListener{
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_view);
        listView=(ListView)findViewById(R.id.listcar);

        CarItem carItem12 = new CarItem();
        carItem12.setTitle("BMW 3 Series");
        carItem12.setImageurl(R.drawable.bmwold);
        carItem12.setEngine("I6 3.0L Natural Aspiration 6");
        carItem12.setCcpower("3993 cc");
        carItem12.setPrice("90,0000,");
        //carItem1.setRating("4.5");
        carItem12.setModel("Series 3");


        CarItem carItem13 = new CarItem();
        carItem13.setTitle("Bently Chrysler");
        carItem13.setModel("Tourying 2008");
        carItem13.setEngine("2.5-liter ");
        carItem13.setCcpower("3902 cc");
        carItem13.setPrice("3,000,00");
        //carItem2.setRating("5");
        carItem13.setImageurl(R.drawable.chrysler);

        CarItem carItem3 = new CarItem();
        carItem3.setTitle("BMW SUV X5");
        carItem3.setModel("2009 Performante");
        carItem3.setEngine("\tI6 3.0L Natural Aspiration");
        carItem3.setCcpower("5204 cc");
        carItem3.setPrice("4,000,00");
        //carItem3.setRating("3");
        carItem3.setImageurl(R.drawable.bmwsuv);

        CarItem carItem4 = new CarItem();
        carItem4.setTitle("Chevrolet LT 4dr");
        carItem4.setModel("812 Superfast");
        carItem4.setEngine("V12 - 65");
        carItem4.setCcpower("6496 cc");
        carItem4.setPrice("50,000,00");
        //carItem4.setRating("2.5");
        carItem4.setImageurl(R.drawable.chv);

        CarItem carItem5 = new CarItem();
        carItem5.setTitle("Porsche 911 GT3");
        carItem5.setModel("911 GT3");
        carItem5.setEngine("Flat 6 Petrol engine");
        carItem5.setCcpower("3996 cc");
        carItem5.setPrice("238,000,00");
        //carItem5.setRating("4");
        carItem5.setImageurl(R.drawable.porsche911);

        CarItem carItem6 = new CarItem();
        carItem6.setTitle("Audi R8 V10 Plus");
        carItem6.setModel("R8 V10 Plus");
        carItem6.setEngine("5.2-litre 601.4bhp 40V Petrol Engine");
        carItem6.setCcpower("5204cc");
        carItem6.setPrice("247,000,00");
        //carItem6.setRating("4.5");
        carItem6.setImageurl(R.drawable.audir8);

        CarItem carItem7 = new CarItem();
        carItem7.setTitle("Ford GT");
        carItem7.setModel("GT");
        carItem7.setEngine("twin-turbo 3.5-liter V-6");
        carItem7.setCcpower("3497 cc");
        carItem7.setPrice("311,385,93");
        //carItem7.setRating("5");
        carItem7.setImageurl(R.drawable.fordgt);

        CarItem carItem8 = new CarItem();
        carItem8.setTitle("Aston Martin DB11");
        carItem8.setModel("DB11");
        carItem8.setEngine("twin-turbo 4.0-liter V-8");
        carItem8.setCcpower("5198 cc");
        carItem8.setPrice("405,000,00");
        //carItem8.setRating("1.5");
        carItem8.setImageurl(R.drawable.astonmartindb11);

        CarItem carItem9 = new CarItem();
        carItem9.setTitle("Lamborghini Aventador S");
        carItem9.setModel("Aventador S");
        carItem9.setEngine("6.5-liter 730-hp V-12");
        carItem9.setCcpower("6498 cc");
        carItem9.setPrice("476,000,00");
        //carItem9.setRating("1");
        carItem9.setImageurl(R.drawable.lamborghiniav);

        CarItem carItem10 = new CarItem();
        carItem10.setTitle("Honda NSX");
        carItem10.setModel("NSX");
        carItem10.setEngine("twin-turbo 3.5-liter V-6");
        carItem10.setCcpower("3500cc");
        carItem10.setPrice("100,000,00");
        //carItem10.setRating("4");
        carItem10.setImageurl(R.drawable.nsx);

        CarItem carItem11 = new CarItem();
        carItem11.setTitle("McLaren 720s");
        carItem11.setModel("720s");
        carItem11.setEngine("710-hp twin-turbo 4.0-liter V-8");
        carItem11.setCcpower("3994cc");
        carItem11.setPrice("430,00,000");
        //carItem11.setRating("4.5");
        carItem11.setImageurl(R.drawable.mclaren);



        ArrayList<CarItem> arrayList=new ArrayList<>();
        arrayList.add(carItem12);
        arrayList.add(carItem13);
        arrayList.add(carItem3);
        arrayList.add(carItem4);
        arrayList.add(carItem5);
        arrayList.add(carItem6);
        arrayList.add(carItem7);
        arrayList.add(carItem8);
        arrayList.add(carItem9);
        arrayList.add(carItem10);
        arrayList.add(carItem11);

        listView.setAdapter(new CarItemAdapter(CarViewActivity2.this,arrayList));

    }

    @Override
    public void onClick(View v) {

    }
}


