package com.verma.asdf.carsell;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FordGt extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ford_gt);

        Button buynow7 = (Button) findViewById(R.id.buynow7);
        buynow7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent buy7 = new Intent(FordGt.this, AddressBuy.class);
                startActivity(buy7);
            }
        });
    }
}
