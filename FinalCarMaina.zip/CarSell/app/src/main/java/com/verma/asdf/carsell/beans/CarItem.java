package com.verma.asdf.carsell.beans;

import java.io.Serializable;

public class CarItem implements Serializable {
    String title;
    String model;
    String engine;
    String ccpower;
    String price;
    //String rating;
    Integer imageurl;

    public Integer getImageurl() {
        return imageurl;
    }

    public void setImageurl(Integer imageurl) {
        this.imageurl = imageurl;
    }

    public String getModel() {
        return model;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getModel(String swift) {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getEngine() {
        return engine;
    }

    public void setEngine(String engine) {
        this.engine = engine;
    }

    public String getCcpower() {
        return ccpower;
    }

    public void setCcpower(String ccpower) {
        this.ccpower = ccpower;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    /*public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }*/
}
