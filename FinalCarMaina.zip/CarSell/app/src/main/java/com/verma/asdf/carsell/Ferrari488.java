package com.verma.asdf.carsell;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Ferrari488 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ferrari488);
        Button buynow2 = (Button) findViewById(R.id.buynow2);
        buynow2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent buy2 = new Intent(Ferrari488.this, AddressBuy.class);
                startActivity(buy2);
            }
        });
    }
}
