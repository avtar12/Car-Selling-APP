package com.verma.asdf.carsell;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ContactUs extends AppCompatActivity implements View.OnClickListener {
TextView call1, call2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_us);
        call1 =(TextView)findViewById(R.id.call1);
        call2=(TextView)findViewById(R.id.call2);
        call2.setOnClickListener(this);
        call1.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.call1)
        {
            String s= "9803330303";
            Intent call = new Intent(Intent.ACTION_DIAL);
            call.setData(Uri.parse("tel:" + s));
            startActivity(call);
        }
        if(v.getId()==R.id.call2)
        {
            String p= "7535695684";
            Intent call3 = new Intent(Intent.ACTION_DIAL);
            call3.setData(Uri.parse("tel:" + p));
            startActivity(call3);
        }

    }
}
