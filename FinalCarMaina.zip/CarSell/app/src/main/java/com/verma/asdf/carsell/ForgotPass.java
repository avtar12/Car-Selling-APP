package com.verma.asdf.carsell;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ForgotPass extends AppCompatActivity implements View.OnClickListener

{
    EditText userf;
    Button next;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_pass);
        userf = (EditText)findViewById(R.id.userf);
        next = (Button)findViewById(R.id.next);
        next.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId()==R.id.next)
        {
            String user=userf.getText().toString();
            if(user.equalsIgnoreCase("admin"))
            {
                Intent intent1=new Intent(ForgotPass.this,DefaultPass.class);
                startActivity(intent1);
            }else {
                Toast.makeText(getBaseContext(), (String)"Username does not exist",Toast.LENGTH_SHORT).show();
            }
        }
    }
}
