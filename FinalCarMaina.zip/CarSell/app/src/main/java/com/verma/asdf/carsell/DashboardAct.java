package com.verma.asdf.carsell;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.ViewFlipper;

public class DashboardAct extends AppCompatActivity {
    ViewFlipper vf;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        ImageView m1 = (ImageView)findViewById(R.id.m1);
        ImageView m2 = (ImageView)findViewById(R.id.m2);
        ImageView m3 = (ImageView)findViewById(R.id.m3);
        ImageView m4 = (ImageView)findViewById(R.id.m4);
        ImageView m5 = (ImageView)findViewById(R.id.m5);
        ImageView m6 = (ImageView)findViewById(R.id.m6);

        vf = (ViewFlipper)findViewById(R.id.viewflip);
        vf.setFlipInterval(2000);
        vf.startFlipping();
    }
}
