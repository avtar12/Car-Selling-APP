package com.verma.asdf.carsell;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class ProfileActivity extends AppCompatActivity {

    private TextView tv_name, tv_address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        tv_name=findViewById(R.id.tv_name);
        tv_address=findViewById(R.id.tv_address);

        Intent intent =getIntent();
        String extraname = intent.getStringExtra("name");
        String extrausername = intent.getStringExtra("email");

        tv_name.setText(extraname);
        tv_address.setText(extrausername);
    }
}
