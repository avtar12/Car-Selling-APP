package com.verma.asdf.carsell;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ViewFlipper;

public class MenuActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    TextView tv, navuser;
    ViewFlipper vf;
    Button signindrawer;
    DrawerLayout drawer;
    ActionBarDrawerToggle toggle;
    ImageView dra1, dra2, dra3, dra4, dra5, dra6;

    //TextView t;
    //ViewFlipper v1;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



       /* ImageView m1=(ImageView)findViewById(R.id.m1);
        ImageView m2=(ImageView)findViewById(R.id.m2);
        ImageView m3=(ImageView)findViewById(R.id.m3);

        /*v1=(ViewFlipper)findViewById(R.id.v1);
        v1.setFlipInterval(2500);
        v1.startFlipping();*/

        signindrawer = (Button) findViewById(R.id.signindrawer);
        ImageView m1 = (ImageView)findViewById(R.id.m1);
        ImageView m2 = (ImageView)findViewById(R.id.m2);
        ImageView m3 = (ImageView)findViewById(R.id.m3);
        ImageView m4 = (ImageView)findViewById(R.id.m4);
        ImageView m5 = (ImageView)findViewById(R.id.m5);
        ImageView m6 = (ImageView)findViewById(R.id.m6);

        dra1 = (ImageView)findViewById(R.id.dra1);
        dra1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent draw1 = new Intent(MenuActivity.this,BuggatiVeyron.class);
                startActivity(draw1);
            }
        });

        dra2 = (ImageView)findViewById(R.id.dra2);
        dra2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent draw2 = new Intent(MenuActivity.this,Ferrari812.class);
                startActivity(draw2);
            }
        });

        dra3 = (ImageView)findViewById(R.id.dra3);
        dra3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent draw3 = new Intent(MenuActivity.this,AudiR8.class);
                startActivity(draw3);
            }
        });

        dra4 = (ImageView)findViewById(R.id.dra4);
        dra4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent draw4 = new Intent(MenuActivity.this,LamborghiniAvantador.class);
                startActivity(draw4);
            }
        });

        dra5 = (ImageView)findViewById(R.id.dra5);
        dra5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent draw5 = new Intent(MenuActivity.this,McLaren.class);
                startActivity(draw5);
            }
        });

        dra6 = (ImageView)findViewById(R.id.dra6);
        dra6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent draw6 = new Intent(MenuActivity.this,FordGt.class);
                startActivity(draw6);
            }
        });



        vf = (ViewFlipper)findViewById(R.id.viewflip);
        vf.setFlipInterval(2500);
        vf.startFlipping();





         drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
         toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }


    @Override
    public void onBackPressed() {
         drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent profile = new Intent(MenuActivity.this, ProfileActivity.class);
            startActivity(profile);
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.aboutus) {
            Intent intent=new Intent(MenuActivity.this,AboutUs.class);
            startActivity(intent);
            // Handle the camera action
        }  else if (id == R.id.nav_manage) {

        }
            else if (id == R.id.nav_share) {
            Intent sharingIntent = new Intent(Intent.ACTION_SEND);
            sharingIntent.setType("text/plain");
            String shareBody = "Buy old and new cars here";
            sharingIntent.putExtra(Intent.EXTRA_SUBJECT, "Car Mania");
            sharingIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
            startActivity(sharingIntent);

        } else if (id == R.id.nav_send) {
            Intent contact = new Intent(MenuActivity.this, ContactUs.class);
            startActivity(contact);
        }
        else if (id == R.id.cat3)
        {
            Intent intent=new Intent(MenuActivity.this,CarViewActivity2.class);
            startActivity(intent);
        }else if (id == R.id.cat2)
        {
            Intent intent=new Intent(MenuActivity.this,CarViewActivity.class);
            startActivity(intent);
        }else if (id == R.id.feedback)
        {
            Intent feed = new Intent(MenuActivity.this, FeedbackActivity.class);
            startActivity(feed);
        }


         drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


}
