package com.verma.asdf.carsell;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.verma.asdf.carsell.fragments.ThankyouFragment;

public class ThankActvity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thank_actvity);
        Button b1=(Button)findViewById(R.id.button4);
        Button b2=(Button)findViewById(R.id.button5);
        b1.setOnClickListener((View.OnClickListener) this);
        b2.setOnClickListener((View.OnClickListener) this);
//        FragmentManager manager=getSupportFragmentManager();
//     FragmentTransaction fragmentTransaction= manager.beginTransaction();
        ThankyouFragment fragment=new ThankyouFragment();
//                fragmentTransaction.add(R.id.container1,fragment).commit();
        getSupportFragmentManager().beginTransaction().replace(R.id.container1,fragment).commit();

    }
}
