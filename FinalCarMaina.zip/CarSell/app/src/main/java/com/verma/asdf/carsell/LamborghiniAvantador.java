package com.verma.asdf.carsell;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class LamborghiniAvantador extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lamborghini_avantador);
        Button buynow9 = (Button) findViewById(R.id.buynow9);
        buynow9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent buy9 = new Intent(LamborghiniAvantador.this, AddressBuy.class);
                startActivity(buy9);
            }
        });
    }
}
